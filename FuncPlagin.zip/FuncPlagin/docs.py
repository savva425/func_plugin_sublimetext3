import sublime_plugin, sublime, json, os

class IntelliDocsCommand(sublime_plugin.TextCommand):
	def __init__(self, view):
		self.view = view

	def run(self, edit):
		selection = self.view.sel()[0]
		code_block = self.view.substr(selection)

		path_db = os.path.dirname(os.path.abspath(__file__)) + '//bd_docs.json'

		with open(path_db, 'r') as j:
		    json_data = json.load(j)
		
		self.view.show_popup(json_data[code_block]["docs"])