
import sublime_plugin, sublime

class IntelliDocsCommand(sublime_plugin.TextCommand):
	def __init__(self, view):
		self.view = view

	def run(self, edit):
		selection = self.view.sel()[0]
		code_block = self.view.substr(selection)


		if code_block == "int": 
		    self.view.show_popup("<div style='height: 200px'>is the type of 257-bit signed integers. By default, overflow checks are enabled and lead to integer overflow exception.</div>")
		elif code_block == "cell": 
		    self.view.show_popup("<div style='height: 200px'>is the type of TVM cells. All persistent data in TON Blockchain is stored in trees of cells. Every cell has up to 1023 bits of arbitrary data in it and up to 4 references to other cells. Cells play a role of memory in stack-based TVM.") 
		elif code_block == "slice": 
		    self.view.show_popup("<div style='height: 200px'>is the type of cell slices. Cell can be transformed to a slice, and then the data bits and references to other cells from the cell can be obtained by loading them from the slice.")
		elif code_block == "builder": 
		    self.view.show_popup("<div style='height: 200px'>is the type of cell builders. Data bits and references to other cells can be stored into a builder, and then the builder can be finalized to a new cell.")
		elif code_block == "tuple": 
		    self.view.show_popup("<div style='height: 200px'>is the type of TVM tuples. Tuple is an ordered collection of up to 255 components, having arbitrary value types, possibly distinct.")
		elif code_block == "cont": 
		    self.view.show_popup("<div style='height: 200px'>is the type of TVM continuations. Continuations are used for controlling the flow of TVM program execution. It is rather a low-level object from the perspective of FunC, although somewhat paradoxically quite general.")